/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Diegocontrerasperez.bd.crud;

import Diegocontrerasperez.bd.crud.exceptions.NonexistentEntityException;
import Diegocontrerasperez.bd.crud.exceptions.PreexistingEntityException;
import Diegocontrerasperez.bd.tablas.Carrerataxi;
import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

/**
 *
 * @author EQUIPO
 */
public class CarrerataxiJpaController implements Serializable {

    public CarrerataxiJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private final EntityManagerFactory emf;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Carrerataxi carrerataxi) throws PreexistingEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(carrerataxi);
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findCarrerataxi(carrerataxi.getId()) != null) {
                throw new PreexistingEntityException("Carrerataxi " + carrerataxi + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Carrerataxi carrerataxi) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            carrerataxi = em.merge(carrerataxi);
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                String id = carrerataxi.getId();
                if (findCarrerataxi(id) == null) {
                    throw new NonexistentEntityException("The carrerataxi with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(String id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Carrerataxi carrerataxi;
            try {
                carrerataxi = em.getReference(Carrerataxi.class, id);
                carrerataxi.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The carrerataxi with id " + id + " no longer exists.", enfe);
            }
            em.remove(carrerataxi);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Carrerataxi> findCarrerataxiEntities() {
        return findCarrerataxiEntities(true, -1, -1);
    }

    public List<Carrerataxi> findCarrerataxiEntities(int maxResults, int firstResult) {
        return findCarrerataxiEntities(false, maxResults, firstResult);
    }

    private List<Carrerataxi> findCarrerataxiEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Carrerataxi.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Carrerataxi findCarrerataxi(String id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Carrerataxi.class, id);
        } finally {
            em.close();
        }
    }

    public int getCarrerataxiCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Carrerataxi> rt = cq.from(Carrerataxi.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
