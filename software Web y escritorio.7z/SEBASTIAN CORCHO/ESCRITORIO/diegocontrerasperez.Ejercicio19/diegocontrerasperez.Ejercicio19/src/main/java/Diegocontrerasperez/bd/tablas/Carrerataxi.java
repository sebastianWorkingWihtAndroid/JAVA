/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Diegocontrerasperez.bd.tablas;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author EQUIPO
 */
@Entity
@Table(name = "carrerataxi", catalog = "ejercicio19", schema = "")
@NamedQueries({
    @NamedQuery(name = "Carrerataxi.findAll", query = "SELECT c FROM Carrerataxi c"),
    @NamedQuery(name = "Carrerataxi.findByPassword", query = "SELECT c FROM Carrerataxi c WHERE c.password = :password"),
    @NamedQuery(name = "Carrerataxi.findByCliente", query = "SELECT c FROM Carrerataxi c WHERE c.cliente = :cliente"),
    @NamedQuery(name = "Carrerataxi.findByTaxi", query = "SELECT c FROM Carrerataxi c WHERE c.taxi = :taxi"),
    @NamedQuery(name = "Carrerataxi.findByKilometros", query = "SELECT c FROM Carrerataxi c WHERE c.kilometros = :kilometros"),
    @NamedQuery(name = "Carrerataxi.findByBarrioInicio", query = "SELECT c FROM Carrerataxi c WHERE c.barrioInicio = :barrioInicio"),
    @NamedQuery(name = "Carrerataxi.findByBarrioLlegada", query = "SELECT c FROM Carrerataxi c WHERE c.barrioLlegada = :barrioLlegada"),
    @NamedQuery(name = "Carrerataxi.findByCanitadadPasajeros", query = "SELECT c FROM Carrerataxi c WHERE c.canitadadPasajeros = :canitadadPasajeros"),
    @NamedQuery(name = "Carrerataxi.findByTaxistas", query = "SELECT c FROM Carrerataxi c WHERE c.taxistas = :taxistas"),
    @NamedQuery(name = "Carrerataxi.findByPrecio", query = "SELECT c FROM Carrerataxi c WHERE c.precio = :precio"),
    @NamedQuery(name = "Carrerataxi.findByDuracionMinutos", query = "SELECT c FROM Carrerataxi c WHERE c.duracionMinutos = :duracionMinutos"),
    @NamedQuery(name = "Carrerataxi.findById", query = "SELECT c FROM Carrerataxi c WHERE c.id = :id")})
public class Carrerataxi implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "password", nullable = false, length = 45)
    private String password;
    @Basic(optional = false)
    @Column(name = "cliente", nullable = false, length = 25)
    private String cliente;
    @Basic(optional = false)
    @Column(name = "taxi", nullable = false, length = 30)
    private String taxi;
    @Basic(optional = false)
    @Column(name = "kilometros", nullable = false, length = 35)
    private String kilometros;
    @Basic(optional = false)
    @Column(name = "barrio_inicio", nullable = false, length = 36)
    private String barrioInicio;
    @Basic(optional = false)
    @Column(name = "barrio_llegada", nullable = false, length = 37)
    private String barrioLlegada;
    @Basic(optional = false)
    @Column(name = "canitadadPasajeros", nullable = false, length = 38)
    private String canitadadPasajeros;
    @Basic(optional = false)
    @Column(name = "taxistas", nullable = false, length = 39)
    private String taxistas;
    @Basic(optional = false)
    @Column(name = "precio", nullable = false, length = 50)
    private String precio;
    @Basic(optional = false)
    @Column(name = "duracionMinutos", nullable = false, length = 60)
    private String duracionMinutos;
    @Id
    @Basic(optional = false)
    @Column(name = "id", nullable = false, length = 34)
    private String id;

    public Carrerataxi() {
    }

    public Carrerataxi(String id) {
        this.id = id;
    }

    public Carrerataxi(String id, String password, String cliente, String taxi, String kilometros, String barrioInicio, String barrioLlegada, String canitadadPasajeros, String taxistas, String precio, String duracionMinutos) {
        this.id = id;
        this.password = password;
        this.cliente = cliente;
        this.taxi = taxi;
        this.kilometros = kilometros;
        this.barrioInicio = barrioInicio;
        this.barrioLlegada = barrioLlegada;
        this.canitadadPasajeros = canitadadPasajeros;
        this.taxistas = taxistas;
        this.precio = precio;
        this.duracionMinutos = duracionMinutos;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public String getTaxi() {
        return taxi;
    }

    public void setTaxi(String taxi) {
        this.taxi = taxi;
    }

    public String getKilometros() {
        return kilometros;
    }

    public void setKilometros(String kilometros) {
        this.kilometros = kilometros;
    }

    public String getBarrioInicio() {
        return barrioInicio;
    }

    public void setBarrioInicio(String barrioInicio) {
        this.barrioInicio = barrioInicio;
    }

    public String getBarrioLlegada() {
        return barrioLlegada;
    }

    public void setBarrioLlegada(String barrioLlegada) {
        this.barrioLlegada = barrioLlegada;
    }

    public String getCanitadadPasajeros() {
        return canitadadPasajeros;
    }

    public void setCanitadadPasajeros(String canitadadPasajeros) {
        this.canitadadPasajeros = canitadadPasajeros;
    }

    public String getTaxistas() {
        return taxistas;
    }

    public void setTaxistas(String taxistas) {
        this.taxistas = taxistas;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public String getDuracionMinutos() {
        return duracionMinutos;
    }

    public void setDuracionMinutos(String duracionMinutos) {
        this.duracionMinutos = duracionMinutos;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Carrerataxi)) {
            return false;
        }
        Carrerataxi other = (Carrerataxi) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Diegocontrerasperez.bd.tablas.Carrerataxi[ id=" + id + " ]";
    }
    
}
