/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Diegocontrerasperez;

import DiegocontrerasperezVentanas.VentanaPrincipal;

/**
 *
 * @author EQUIPO
 */
public class Principal {
public static void main(String a[]){
System.out.println("funcionando");    
VentanaPrincipal v = new VentanaPrincipal();
v.setExtendedState(VentanaPrincipal.MAXIMIZED_BOTH);
v.setVisible(true);
    }    
}
