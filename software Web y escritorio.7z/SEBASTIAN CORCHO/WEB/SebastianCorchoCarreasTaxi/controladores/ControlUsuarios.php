<?php
session_start();
require_once '../modelo/Carreataxi.php';


/**
 * Description of ControlUsuarios
 *
 * @author SEBASTIAN CORCHO
 */
class ControlUsuarios {
    public function ejecutar_accion($accion) {
        switch ($accion){
            case "LOGIN":
                $this->iniciar_sesion();
                break;
            
            case "GUARDAR":
                $this->guardar_usuario(NULL);
                break;
            
             case "BUSCAR":
                $this->buscar_usuario();
                break;
            
             case "EDITAR":
                 $u = $_SESSION["usuario.find"];
                 $u= unserialize($u);
                $this->guardar_usuario($u);
                break;
            
             case "ELIMINAR":
                $this->eliminar_usuario();
                break;
            
            
            default :
                break;
        }
    }

    public function iniciar_sesion() {
        $id = $_REQUEST["id"];
        $password = $_REQUEST["password"];
        
        try {
            
            $u = Carreataxi::find_by_id($id);
            
            if ($u!=NULL || isset($u)){
                if($u->password == $password) {
            
             header("Location:../web/index.php");   
             exit;
            } else {
                
              header("Location:../index.php?msj=Clave Incorrecta");
            exit;   
                
            }
            
            }else{
                header("Location:../index.php?msj=Usuario No Existe");
            exit;
            }
            
        } catch (Exception $ex) {
            header("Location:../index.php?msj=Usuario No Existe");
            exit;
        }
    }

    public function guardar_usuario($u) {
        
        $id = @$_REQUEST["id"];
        $password = @$_REQUEST["password"];
        $cliente = @$_REQUEST["cliente"];
        $taxi = @$_REQUEST["taxi"];
        $kilometros = @$_REQUEST["kilometros"];
        $barrio_inicio = @$_REQUEST["barrio_inicio"];
        $barrio_llegada = @$_REQUEST["barrio_llegada"];
        $cantidad_pasajeros = @$_REQUEST["cantidad_pasajeros"];
        $taxista = @$_REQUEST["taxista"];
        $precio = @$_REQUEST["precio"];
        $duracion_minutos = @$_REQUEST["duracion_minutos"];
        
        
        
         $res=$this->validar_campo($id);
         if ($res) {
                         header("Location: ../web/carreastaxi/agregar.php?msj=El ID es necesario");
                         exit;
                     }
                     
                       $res=$this->validar_campo($password);
         if ($res) {
                         header("Location: ../web/carreastaxi/agregar.php?msj=La clave es necesario");
                         exit;
                     }
        
      

                     
         $res=$this->validar_campo($cliente);
         if ($res) {
                         header("Location: ../web/carreastaxi/agregar.php?msj=El Cliente es necesario");
                         exit;
                     }
         $res=$this->validar_campo($taxi);
         if ($res) {
                         header("Location: ../web/carreastaxi/agregar.php?msj=La placa del taxi es necesario");
                         exit;
                     }
                     
                      $res=$this->validar_campo($kilometros);
         if ($res) {
                         header("Location: ../web/carreastaxi/agregar.php?msj=El Kilometraje es necesario");
                         exit;
                     }
                     
                      $res=$this->validar_campo($barrio_inicio);
         if ($res) {
                         header("Location: ../web/carreastaxi/agregar.php?msj=El Barrio de inicio es necesario");
                         exit;
                     }
                     
                      $res=$this->validar_campo($barrio_llegada);
         if ($res) {
                         header("Location: ../web/carreastaxi/agregar.php?msj=El Barrio de llegada es necesario");
                         exit;
                     }
                     
                      $res=$this->validar_campo($cantidad_pasajeros);
         if ($res) {
                         header("Location: ../web/carreastaxi/agregar.php?msj=La Cantidad de pasajeros es necesario");
                         exit;
                     }
                     
                      $res=$this->validar_campo($precio);
         if ($res) {
                         header("Location: ../web/carreastaxi/agregar.php?msj=El Precio es necesario");
                         exit;
                     }
                     
                      $res=$this->validar_campo($duracion_minutos);
         if ($res) {
                         header("Location: ../web/carreastaxi/agregar.php?msj=La Cantidad de tiempo es necesario");
                         exit;
                     }
                     
                     $pagina ="buscar";
                     $msj = "Usuario actualizado";
                     $total="";
                     try {
                         if ($u==NULL) {
                             $u=new Carreataxi();
                             $u-> id = $id;
                             $pagina="agregar";
                             
                             $total = Carreataxi::count();
                             $msj = "Usuario Registrado, Total: ".$total;
                         }
                         
                         $u-> password = $password;
                         $u-> cliente = $cliente;
                         $u-> taxi = $taxi;
                         $u-> kilometros = $kilometros;
                         $u-> barrio_inicio = $barrio_inicio;
                         $u-> barrio_llegada = $barrio_llegada;
                         $u-> cantidad_pasajeros = $cantidad_pasajeros;
                         $u-> taxista = $taxista;
                         $u-> precio = $precio;
                         $u-> duracion_minutos = $duracion_minutos;
                         $u->save();
                         if ($pagina=="buscar") {
                              $_SESSION["usuario.find"]=$u;     
                         } else {
                                  $_SESSION["usuario.find"]=NULL;     
                         }
                         header("Location: ../web/carreastaxi/$pagina.php?msj=$msj");
                         exit;
                     } catch (Exception $error) {
                         $msj = $error->getMessage();
                         if (strstr( $msj,"Duplicate")) {
                             header("Location: ../web/carreastaxi/$pagina.php?msj=$Usuario Existente");
                         }else{
                             
                             
                         header("Location: ../web/carreastaxi/$pagina.php?msj=Usuario Registrado");
                         exit;
                             
                         }
                         
                     }
                                      
                     
        
    }
    
    private function validar_campo($campo) {
        if ($campo == NULL ||empty($campo) || !isset($campo)) {
            
            return true;
        }else{
            return false;
        }
    }

    public function buscar_usuario() {
        
        $id = @$_REQUEST["id"];
        $res=$this->validar_campo($id);
         if ($res) {
         header("Location: ../web/carreastaxi/buscar.php?msj=El usuario es necesario");
         exit;
        }
        try {
            $u = Carreataxi::find($id);
            $u = serialize($u);
            $_SESSION["usuario.find"]=$u;
            header("Location: ../web/carreastaxi/buscar.php");
            exit;
        } catch (Exception $exc) {
            header("Location: ../web/carreastaxi/buscar.php?msj=El Usuario no existe");
            $_SESSION["usuario.find"]=NULL;
            exit;
        }

        
    }

    public function eliminar_usuario() {
          $id = @$_REQUEST["id"];
        $res=$this->validar_campo($id);
         if ($res) {
         header("Location: ../web/carreastaxi/buscar.php?msj=El usuario es necesario");
         exit;
        }
        $u = $_SESSION["usuario.find"];
        $u = unserialize($u);
        $u->delete();
        $_SESSION["usuario.find"]=NULL;
        $total= Carreataxi::count();
        $msj="Usuario Eliminado";
        header("Location: ../web/carreastaxi/buscar.php?msj=".$msj);
         exit;
    }

}

$accion = @$_REQUEST["accion"];
if ($accion !=NULL) {
    $controlador = new ControlUsuarios();
    $controlador ->ejecutar_accion($accion);
} else{
    header("Location:../index.php?msj=Debe Iniciar Sesion");
            
}
    
