<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
session_start();
require_once '../../modelo/Carreataxi.php';
$msj= @$_REQUEST["msj"];
$u = @$_SESSION["usuario.find"];
$u = unserialize($u);
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Inicio</title>
        <script src="../../js/mis_funciones.js" type="text/javascript"></script>
    </head>
    <body>
    <center>
        <form action="../../controladores/ControlUsuarios.php" onsubmit="confirmar (document.getElementById())">
            <fieldset style="width: 30%">
            <legend>INICIAR SESION</legend>
            <table border="1">
                
                  <tr>
                    <th>ID</th>
                    <td><input type="text" name="id" placeholder="Ingrese Usuario" required="" value="<?= ($u)? $u->id: "" ?>"></td>
                </tr>
                
                
                 <tr>
                    <th>PASSWORD</th>
                    <td><input type="password" name="password" placeholder="Ingrese Clave" value="<?= ($u)? $u->password: "" ?>"></td>
                </tr>
                
                 
               
                <tr>
                    <th>CLIENTE</th>
                    <td><input type="text" name="cliente" placeholder="Ingrese Cliente" value="<?= ($u)? $u->cliente: "" ?>"></td>
                </tr>
                
                <tr>
                    <th>TAXI</th>
                    <td><input type="text" name="taxi" placeholder="Ingrese Placa" value="<?= ($u)? $u->taxi: "" ?>"></td>
                </tr>
                
                 <tr>
                    <th>KILOMETROS</th>
                    <td><input type="text" name="kilometros" placeholder="Ingrese Kilometraje" value="<?= ($u)? $u->kilometros: "" ?>"></td>
                </tr>
                
                 <tr>
                    <th>BARRIO DE INICIO</th>
                    <td><input type="text" name="barrio_inicio" placeholder="Barrio de Inicio" value="<?= ($u)? $u->barrio_inicio: "" ?>"></td>
                </tr>
                
                 <tr>
                    <th>BARRIO DE LLEGADA</th>
                    <td><input type="text" name="barrio_llegada" placeholder="Barrio de LLegada" value="<?= ($u)? $u->barrio_llegada: "" ?>"></td>
                </tr>
                
                 <tr>
                    <th>CANTIDAD PASAJEROS</th>
                    <td><input type="number" name="cantidad_pasajeros" placeholder="Cantidad Pasajeros" value="<?= ($u)? $u->cantidad_pasajeros: "" ?>"></td>
                </tr>
                
                 <tr>
                    <th>TAXISTA</th>
                    <td><input type="text" name="taxista" placeholder="Nombre taxista" value="<?= ($u)? $u->taxista: "" ?>"></td>
                </tr>
                
                 <tr>
                    <th>PRECIO</th>
                    <td><input type="number" name="precio" placeholder="Ingrese Clave" value="<?= ($u)? $u->precio: "" ?>"></td>
                </tr>
                
                 <tr>
                    <th>DURACION EN MINUTOS</th>
                    <td><input type="number" name="duracion_minutos" placeholder="Ingrese Clave" value="<?= ($u)? $u->duracion_minutos: "" ?>"></td>
                </tr>
                
                <tr>
                    <td colspan="2" style="text-align: right">
                    <input type="reset" value="LIMPIAR">&nbsp;&nbsp;&nbsp;
                    <input type="submit" name="accion" id="eliminar" value="ELIMINAR">
                    <input type="submit" name="accion" id="editar" value="EDITAR">&nbsp;&nbsp;&nbsp;
                    <input type="submit" name="accion" id="buscar" value="BUSCAR">
                    
                </tr>
                
            </table>
        </fieldset>
            </form>
        <span style="color: red"><?= @$msj?></span>
    </center>
        <?php
        // put your code here
        ?>
    </body>
</html>
