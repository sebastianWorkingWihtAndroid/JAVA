<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Inicio</title>
    </head>
    <body>
    <center>
        <fieldset>
            <legend>MENÚ DE OPERACIONES</legend>
            <table>
                <tr>
                    <th><a href="agregar.php">AGREGAR</a></th>
                </tr>
                
                <tr>
                    <th><a href="buscar.php">BUSCAR</a></th>
                </tr>
                
                <tr>
                    <th><a href="buscar.php">ELIMINAR</a></th>
                </tr>
                
                 <tr>
                    <th><a href="buscar.php">EDITAR</a></th>
                </tr>
                
                  <tr>
                    <th><a href="listar_todo.php">LISTAR</a></th>
                </tr>
           
           
            </table>
        </fieldset>
    </center>
        <?php
        // put your code here
        ?>
    </body>
</html>
