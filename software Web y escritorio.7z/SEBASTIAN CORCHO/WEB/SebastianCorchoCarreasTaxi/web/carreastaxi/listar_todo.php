<?php session_start();
require_once '../../modelo/Carreataxi.php';
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Inicio</title>
    </head>
    <body>
    <center>
        <fieldset>
            <legend>DATOS DE TODA LA TABLA</legend>
            <?php  
           $Lista_de_usuarios = Carreataxi::all();
if (count($Lista_de_usuarios)<=0) {
    echo "SIN USUARIOS QUE MOSTRAR";
}else{
?>

<table border="1">
    <tr>
        <th>No</th>
        <th>ID</th>
        <th>CLIENTE</th>
        <th>TAXI</th>
        <th>KILOMETROS</th>
        <th>BARRIO DE INICIO</th>
        <th>BARRIO DE LLEGADA</th>
        <th>CANTIDAD DE PASAJEROS</th>
        <th>TAXISTA</th>
        <th>PRECIO</th>
        <th>DURACION EN MINUTOS</th>
           
    </tr>
    <?php
    $cuenta=1;
    foreach ($Lista_de_usuarios as $u) {
        ?>
    <tr>
        <td><?=$cuenta ?></td>
        <td><?=$u->id?></td>
        <td><?=$u->cliente?></td>
        <td><?=$u->taxi?></td>
        <td><?=$u->kilometros?></td>
        <td><?=$u->barrio_inicio?></td>
        <td><?=$u->barrio_llegada?></td>
        <td><?=$u->cantidad_pasajeros?></td>
        <td><?=$u->taxista?></td>
        <td><?=$u->precio?></td>
        <td><?=$u->duracion_minutos?></td>
        
        
    </tr>
    <?php
    $cuenta++;
    }
    ?>
    <tr>
        <td colspan="11" style="text-align: right">TOTAL</td>
        <td colspan="2" style="text-align: left">//<?=count($Lista_de_usuarios)?></td>
    </tr>
        
</table>
<?php
}
?>
        </fieldset>
    </center>
        <?php
        // put your code here
        ?>
    </body>
</html>
