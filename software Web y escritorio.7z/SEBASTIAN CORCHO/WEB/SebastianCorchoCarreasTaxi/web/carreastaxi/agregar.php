<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
$msj= @$_REQUEST["msj"];
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Inicio</title>
        <script src="../../js/mis_funciones.js" type="text/javascript"></script>
            
    </head>
    <body>
    <center>
        <form action="../../controladores/ControlUsuarios.php"  onsubmit="return confirmar("AGREGAR");">
            <fieldset style="width: 30%">
            <legend>INICIAR SESION</legend>
            <table border="1">
                
                  <tr>
                    <th>ID</th>
                    <td><input type="text" name="id" placeholder="Ingrese Usuario" required=""></td>
                </tr>
                
                
                 <tr>
                    <th>PASSWORD</th>
                    <td><input type="password" name="password" placeholder="Ingrese Clave" required=""></td>
                </tr>
                
                 
               
                <tr>
                    <th>CLIENTE</th>
                    <td><input type="text" name="cliente" placeholder="Ingrese Cliente" required=""></td>
                </tr>
                
                <tr>
                    <th>TAXI</th>
                    <td><input type="text" name="taxi" placeholder="Ingrese Placa" required=""></td>
                </tr>
                
                 <tr>
                    <th>KILOMETROS</th>
                    <td><input type="text" name="kilometros" placeholder="Ingrese Kilometraje" required=""></td>
                </tr>
                
                 <tr>
                    <th>BARRIO DE INICIO</th>
                    <td><input type="text" name="barrio_inicio" placeholder="Barrio de Inicio" required=""></td>
                </tr>
                
                 <tr>
                    <th>BARRIO DE LLEGADA</th>
                    <td><input type="text" name="barrio_llegada" placeholder="Barrio de LLegada" required=""></td>
                </tr>
                
                 <tr>
                    <th>CANTIDAD PASAJEROS</th>
                    <td><input type="number" name="cantidad_pasajeros" placeholder="Cantidad Pasajeros" required=""></td>
                </tr>
                
                 <tr>
                    <th>TAXISTA</th>
                    <td><input type="text" name="taxista" placeholder="Nombre taxista" required=""></td>
                </tr>
                
                 <tr>
                    <th>PRECIO</th>
                    <td><input type="number" name="precio" placeholder="Ingrese Clave" required=""></td>
                </tr>
                
                 <tr>
                    <th>DURACION EN MINUTOS</th>
                    <td><input type="number" name="duracion_minutos" placeholder="Ingrese Clave" required=""></td>
                </tr>
                
                <tr>
                    <td colspan="2" style="text-align: right">
                    <input type="reset" value="LIMPIAR">&nbsp;&nbsp;&nbsp;
                    <input type="submit" name="accion" value="GUARDAR">&nbsp;&nbsp;&nbsp;
                </tr>
                
            </table>
        </fieldset>
            </form>
        <span style="color: red"><?= @$msj?></span>
    </center>
        <?php
        // put your code here
        ?>
    </body>
</html>
