<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>MVC</title>
    </head>
    <body>
    <center>
        <fieldset>
            <legend>MENÚ PARA REALIZAR OPERACIONES SOBRE LA TABLA</legend>
            <table>
                <tr>
                    <th><a href="carreastaxi/index.php">CARRERA DE TAXI</a></th>
                </tr>
           
            </table>
        </fieldset>
    </center>
        <?php
        // put your code here
        ?>
    </body>
</html>
