<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
$msj= @$_REQUEST["msj"];
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Inicio</title>
    </head>
    <body>
    <center>
        <form action="controladores/ControlUsuarios.php">
            <fieldset style="width: 30%">
            <legend>INICIAR SESION</legend>
            <table>
                <tr>
                    <th>ID</th>
                    <td><input type="text" name="id" placeholder="Ingrese Usuario" required=""></td>
                </tr>
                <tr>
                    <th>CLAVE</th>
                    <td><input type="password" name="password" placeholder="Ingrese Clave" required=""></td>
                </tr>
                <tr>
                    <td colspan="2" style="text-align: right">
                    <input type="reset" value="LIMPIAR">&nbsp;&nbsp;&nbsp;
                    <input type="submit" name="accion" value="LOGIN">&nbsp;&nbsp;&nbsp;
                </tr>
                
            </table>
        </fieldset>
            </form>
        <span style="color: red"><?= @$msj?></span>
    </center>
        <?php
        // put your code here
        ?>
    </body>
</html>
