function confirmar(msj){
    confirm("¿Seguro que desea "+msj+" ?");
}


