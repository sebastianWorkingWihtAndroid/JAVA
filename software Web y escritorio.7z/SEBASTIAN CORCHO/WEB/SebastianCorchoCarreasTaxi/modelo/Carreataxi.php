<?php

require_once $_SERVER['DOCUMENT_ROOT']."/SebastianCorchoCarreasTaxi/lib/config.php";

class Carreataxi extends ActiveRecord\Model{
    public static $table_name="";
    public static $primary_key="id";
    
}
