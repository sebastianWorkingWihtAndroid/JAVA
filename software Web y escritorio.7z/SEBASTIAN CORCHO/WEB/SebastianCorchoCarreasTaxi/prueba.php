<?php 
require_once 'modelo/Carreataxi.php';

//INSERTAR
//$u=new Carreataxi();
//$u->id;
//$u->password='12345';
//$u->cliente='a';
//$u->taxi='b';
//$u->kilometros='c';
//$u->barrio_inicio='corchoo';
//$u->barrio_llegada='corchoo';
//$u->cantidad_pasajeros='corchoo';
//$u->taxista='corchoo';
//$u->precio='corchoo';
//$u->duracion_minutos='corchoo';
//
//
//
//try {
//    $u->save();
//    $total= Carreataxi::count();
//    echo "total: ".$total;
//} catch (Exception $error) {
//    echo "Error al insertar <br>".$error->getMessage();
//}


//BUSCAR
$u = Carreataxi::find(2);
//echo "Id: ".$u->id;
//echo "Password: ".$u->password;
//echo "Cliente: ".$u->cliente;
//echo "Taxi: ".$u->taxi;
//echo "Kilometros: ".$u->kilometros;
//echo "Barrio de Inicio: ".$u->barrio_inicio;
//echo "Cantidad de Pasajeros: ".$u->cantidad_pasajeros;
//echo "Taxista: ".$u->taxista;
//echo "Precio: ".$u->barrio_llegada;
//echo "Duracion de Minutos: ".$u->duracion_minutos;
//
//
////ACTUALIZAR
////$u=new Carreataxi();
////$u->id;
//$u->password='he cambiado';
////$u->cliente='a';
////$u->taxi='b';
//$u->kilometros='10';
////$u->barrio_inicio='corchoo';
////$u->barrio_llegada='corchoo';
////$u->cantidad_pasajeros='corchoo';
////$u->taxista='corchoo';
////$u->precio='corchoo';
////$u->duracion_minutos='corchoo';
//echo "Actualizando...";
//
//$u->save();
//
//echo "<hr>";
//
////mMOSTRAR DE NUEVO
//$u = Carreataxi::find(1);
//echo "Id: ".$u->id;
//echo "Password: ".$u->password;
//echo "Cliente: ".$u->cliente;
//echo "Taxi: ".$u->taxi;
//echo "Kilometros: ".$u->kilometros;
//echo "Barrio de Inicio: ".$u->barrio_inicio;
////echo "Barrio de LLegada: ".$u->barrio_llegada;
//echo "Cantidad de Pasajeros: ".$u->cantidad_pasajeros;
//echo "Taxista: ".$u->taxista;
//echo "Precio: ".$u->barrio_llegada;
//echo "Duracion de Minutos: ".$u->duracion_minutos;

//$u=NULL;
//try {
//    $u = Carreataxi::find(1);
//} catch (Exception $ex) {
//    echo "<hr>";
//    echo "NO EXISTE";
//    echo "<hr>";
//}
//
//;
//
//if ($u !=NULL) {
//    echo "<hr>";
//    echo "ELIMINANDO";
//    $u->delete();
//    echo "<hr>";
//    
//}else{
//    
//}

//LISTAR
$Lista_de_usuarios = Carreataxi::all();
if (count($Lista_de_usuarios)<=0) {
    echo "SIN USUARIOS QUE MOSTRAR";
}else{
?>

<table border="1">
    <tr>
        <th>ID</th>
        <th>CLIENTE</th>
        <th>TAXI</th>
        <th>KILOMETROS</th>
        <th>BARRIO DE INICIO</th>
        <th>BARRIO DE LLEGADA</th>
        <th>CANTIDAD DE PASAJEROS</th>
        <th>TAXISTA</th>
        <th>PRECIO</th>
        <th>DURACION EN MINUTOS</th>
           
    </tr>
    <?php
    foreach ($Lista_de_usuarios as $u) {
        ?>
    <tr>
        <td>//<?=$u->id?></td>
        <td>//<?=$u->cliente?></td>
        <td>//<?=$u->taxi?></td>
        <td>//<?=$u->kilometros?></td>
        <td>//<?=$u->barrio_inicio?></td>
        <td>//<?=$u->barrio_llegada?></td>
        <td>//<?=$u->cantidad_pasajeros?></td>
        <td>//<?=$u->taxista?></td>
        <td>//<?=$u->precio?></td>
        <td>//<?=$u->duracion_minutos?></td>
        
        
    </tr>
    <?php
    }
    ?>
    <tr>
        <td colspan="11" style="text-align: right">TOTAL</td>
        <td colspan="2" style="text-align: left">//<?=count($Lista_de_usuarios)?></td>
    </tr>
        
</table>
<?php
}
?>








/* 
 * 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

